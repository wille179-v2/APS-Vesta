--Set Vesta's legacy setting default to false instead
data.raw["bool-setting"]["ske_vesta_legacy_recipes"].default_value = false