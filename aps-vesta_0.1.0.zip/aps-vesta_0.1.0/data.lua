
-- Adds Vesta to Any Planet Start All other changes should be done in aps-vesta.lua
APS.add_planet({
	name = "vesta",
	filename = "__aps-vesta__/aps-vesta.lua",
	technology = "planet-discovery-vesta",
})