
script.on_init(function()
local vestaStart = (settings.startup["aps-planet"].value == "vesta")

if not remote.interfaces["freeplay"] then return end
if not vestaStart then return end

remote.call("freeplay", "set_ship_items", {
	["biochamber"] = 1
})


end)